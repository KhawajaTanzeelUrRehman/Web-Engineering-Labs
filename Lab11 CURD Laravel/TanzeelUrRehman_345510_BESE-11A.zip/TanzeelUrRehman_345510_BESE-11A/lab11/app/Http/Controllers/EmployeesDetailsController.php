<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Employee;


class EmployeesDetailsController extends Controller
{
    public function index()
    {
        $employees = Employee::all();
        return view('dashboard', ['employees' => $employees]);
    }
}
