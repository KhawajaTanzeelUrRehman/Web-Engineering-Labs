<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\Employee;
use App\Providers\RouteServiceProvider;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;

class RegisteredUserController extends Controller
{
    /**
     * Display the registration view.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('auth.register');
    }

    /**
     * Handle an incoming registration request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
        $request->validate([
            'username' => ['required', 'string', 'max:255', 'unique:' . Employee::class],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:' . Employee::class],
            'password' => ['required', 'confirmed', Rules\Password::defaults()], 'username' => ['required', 'string', 'max:255', 'unique:' . Employee::class],
            'lastName' => ['required', 'string', 'max:255'],
            'firstName' => ['required', 'string', 'max:255'],
            'extension' => ['required', 'string', 'max:255'],
            'jobTitle' => ['required', 'string', 'max:255'],
            'officeCode' => ['required', 'string', 'max:255'],
            'reportsTo' => ['required', 'string', 'max:255'],
        ]);

        $user = Employee::create([
            'username' => $request->username,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'lastName' => $request->lastName,
            'firstName' => $request->firstName,
            'extension' => $request->extension,
            'jobTitle' => $request->jobTitle,
            'officeCode' => $request->officeCode,
            'reportsTo' => $request->reportsTo,

        ]);

        event(new Registered($user));

        Auth::login($user);

        return redirect(RouteServiceProvider::HOME);
    }
}
