<section>
    <header>

        <h2 class="g font-medium text-gray-900 dark:text-gray-100">
            {{ __('Complete Details:') }}
        </h2>
    </header>

<div class="flex flex-row mt-4">
    <div class="basis-1/2  text-white">First Name: &nbsp;</div>
    <div class="basis-1/2  text-white ">{{ $user->firstName }}</div>
</div>
<div class="flex flex-row mt-4">
    <div class="basis-1/2  text-white">Last Name: &nbsp;</div>
    <div class="basis-1/2  text-white ">{{ $user->lastName }}</div>
</div>
<div class="flex flex-row mt-4">
    <div class="basis-1/2  text-white">Email: &nbsp;</div>
    <div class="basis-1/2  text-white ">{{ $user->email }}</div>
</div>
<div class="flex flex-row mt-4">
    <div class="basis-1/2  text-white">extension: &nbsp;</div>
    <div class="basis-1/2  text-white ">{{ $user->extension }}</div>
</div>
<div class="flex flex-row mt-4">
    <div class="basis-1/2  text-white">Office Code: &nbsp;</div>
    <div class="basis-1/2  text-white ">{{ $user->officeCode }}</div>
</div>
<div class="flex flex-row mt-4">
    <div class="basis-1/2  text-white">Job Title: &nbsp;</div>
    <div class="basis-1/2  text-white ">{{ $user->jobTitle }}</div>
</div>

<div class="flex flex-row mt-4">
    <div class="basis-1/2  text-white">Employee Number: &nbsp;</div>
    <div class="basis-1/2  text-white ">{{ $user->employeeNumber }}</div>
</div>
<div class="flex flex-row mt-4">
    <div class="basis-1/2  text-white">User Name: &nbsp;</div>
    <div class="basis-1/2  text-white ">{{ $user->username }}</div>
</div>



</section>
