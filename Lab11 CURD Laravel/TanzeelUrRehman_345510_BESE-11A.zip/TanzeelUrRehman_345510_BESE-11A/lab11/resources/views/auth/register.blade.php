<x-guest-layout>
    <x-auth-card>
        <x-slot name="logo">
            <a href="/">
                <x-application-logo class="w-20 h-20 fill-current text-gray-500" />
            </a>
        </x-slot>

        <form method="POST" action="{{ route('register') }}">
            @csrf

            <!-- User Name -->
            <div>
                <x-input-label for="username" :value="__('User Name')" />
                <x-text-input id="username" class="block mt-1 w-full" type="text" name="username" :value="old('username')" required autofocus />
                <x-input-error :messages="$errors->get('username')" class="mt-2" />
            </div>

            <!-- Email Address -->
            <div class="mt-4">
                <x-input-label for="email" :value="__('Email')" />
                <x-text-input id="email" class="block mt-1 w-full" type="email" name="email" :value="old('email')" required />
                <x-input-error :messages="$errors->get('email')" class="mt-2" />
            </div>

            <!-- Password -->
            <div class="mt-4">
                <x-input-label for="password" :value="__('Password')" />

                <x-text-input id="password" class="block mt-1 w-full"
                                type="password"
                                name="password"
                                required autocomplete="new-password" />

                <x-input-error :messages="$errors->get('password')" class="mt-2" />
            </div>

            <!-- Confirm Password -->
            <div class="mt-4">
                <x-input-label for="password_confirmation" :value="__('Confirm Password')" />

                <x-text-input id="password_confirmation" class="block mt-1 w-full"
                                type="password"
                                name="password_confirmation" required />

                <x-input-error :messages="$errors->get('password_confirmation')" class="mt-2" />
            </div>

            <!-- lastName -->
            <div>
                <x-input-label for="lastName" :value="__('Last Name')" />
                <x-text-input id="lastName" class="block mt-1 w-full" type="text" name="lastName" :value="old('lastName')" required autofocus />
                <x-input-error :messages="$errors->get('lastName')" class="mt-2" />
            </div>

            <!-- firstName -->
            <div>
                <x-input-label for="firstName" :value="__('First Name')" />
                <x-text-input id="firstName" class="block mt-1 w-full" type="text" name="firstName" :value="old('firstName')" required autofocus />
                <x-input-error :messages="$errors->get('firstName')" class="mt-2" />
            </div>
            
            <!-- extension -->
            <div>
                <x-input-label for="extension" :value="__('Extension')" />
                <x-text-input id="extension" class="block mt-1 w-full" type="text" name="extension" :value="old('extension')" required autofocus />
                <x-input-error :messages="$errors->get('extension')" class="mt-2" />
            </div>

            <!-- jobTitle -->
            <div>
                <x-input-label for="jobTitle" :value="__('Job Title')" />
                <x-text-input id="jobTitle" class="block mt-1 w-full" type="text" name="jobTitle" :value="old('jobTitle')" required autofocus />
                <x-input-error :messages="$errors->get('jobTitle')" class="mt-2" />
            </div>

            <!-- officeCode -->
            <div>
                <x-input-label for="officeCode" :value="__('Office Code')" />
                <x-text-input id="officeCode" class="block mt-1 w-full" type="text" name="officeCode" :value="old('officeCode')" required autofocus />
                <x-input-error :messages="$errors->get('officeCode')" class="mt-2" />

            </div>

            <!-- reportsTo -->
            <div>
                <x-input-label for="reportsTo" :value="__('Reports To')" />
                <x-text-input id="reportsTo" class="block mt-1 w-full" type="text" name="reportsTo" :value="old('reportsTo')" required autofocus />
                <x-input-error :messages="$errors->get('reportsTo')" class="mt-2" />
            </div>

            

            <div class="flex items-center justify-end mt-4">
                <a class="underline text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800" href="{{ route('login') }}">
                    {{ __('Already registered?') }}
                </a>

                <x-primary-button class="ml-4">
                    {{ __('Register') }}
                </x-primary-button>
            </div>
        </form>
    </x-auth-card>
</x-guest-layout>
