<section>
    <header>

        <h2 class="g font-medium text-gray-900 dark:text-gray-100">
            <?php echo e(__('Complete Details:')); ?>

        </h2>
    </header>

<div class="flex flex-row mt-4">
    <div class="basis-1/2  text-white">First Name: &nbsp;</div>
    <div class="basis-1/2  text-white "><?php echo e($user->firstName); ?></div>
</div>
<div class="flex flex-row mt-4">
    <div class="basis-1/2  text-white">Last Name: &nbsp;</div>
    <div class="basis-1/2  text-white "><?php echo e($user->lastName); ?></div>
</div>
<div class="flex flex-row mt-4">
    <div class="basis-1/2  text-white">Email: &nbsp;</div>
    <div class="basis-1/2  text-white "><?php echo e($user->email); ?></div>
</div>
<div class="flex flex-row mt-4">
    <div class="basis-1/2  text-white">extension: &nbsp;</div>
    <div class="basis-1/2  text-white "><?php echo e($user->extension); ?></div>
</div>
<div class="flex flex-row mt-4">
    <div class="basis-1/2  text-white">Office Code: &nbsp;</div>
    <div class="basis-1/2  text-white "><?php echo e($user->officeCode); ?></div>
</div>
<div class="flex flex-row mt-4">
    <div class="basis-1/2  text-white">Job Title: &nbsp;</div>
    <div class="basis-1/2  text-white "><?php echo e($user->jobTitle); ?></div>
</div>

<div class="flex flex-row mt-4">
    <div class="basis-1/2  text-white">Employee Number: &nbsp;</div>
    <div class="basis-1/2  text-white "><?php echo e($user->employeeNumber); ?></div>
</div>
<div class="flex flex-row mt-4">
    <div class="basis-1/2  text-white">User Name: &nbsp;</div>
    <div class="basis-1/2  text-white "><?php echo e($user->username); ?></div>
</div>



</section>
<?php /**PATH C:\xampp\htdocs\lab11\resources\views/profile/partials/user-details.blade.php ENDPATH**/ ?>