import React, { Component } from "react";
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button';
import axios from 'axios';

export default class CreateBook extends Component {

  constructor(props) {
    super(props)

    // Setting up functions
    this.onChangeBooktitle = this.onChangeBooktitle.bind(this);
    this.onChangeBookisbn = this.onChangeBookisbn.bind(this);
    this.onChangeBookpageCount = this.onChangeBookpageCount.bind(this);

    this.onChangeBookpublishedDate = this.onChangeBookpublishedDate.bind(this);
    this.onChangeBookthumbnailUrl = this.onChangeBookthumbnailUrl.bind(this);
    this.onChangeBookshortDescription = this.onChangeBookshortDescription.bind(this);
    this.onChangeBooklongDescription = this.onChangeBooklongDescription.bind(this);
    this.onChangeBookstatus = this.onChangeBookstatus.bind(this);
    this.onChangeBookauthors = this.onChangeBookauthors.bind(this);
    this.onChangeBookcategories = this.onChangeBookcategories.bind(this);
    this.onSubmit = this.onSubmit.bind(this);

    // Setting up state
    this.state = {
      title: '',
      isbn: '',
      pageCount: '',
      publishedDate: '',
      thumbnailUrl: '',
      shortDescription: '',
      longDescription: '',
      status: '',
      authors: '',
      categories: ''
    }
  }

  onChangeBooktitle(e) {
    this.setState({ title: e.target.value })
  }

  onChangeBookisbn(e) {
    this.setState({ isbn: e.target.value })
  }
  onChangeBookpageCount(e) {
    this.setState({ pageCount: e.target.value })
  }
  onChangeBookpublishedDate(e){
    this.setState({ publishedDate: e.target.value })
  }
  onChangeBookthumbnailUrl(e){
    this.setState({ thumbnailUrl: e.target.value })
  }
  onChangeBookshortDescription(e){
    this.setState({ shortDescription: e.target.value })
  }
  onChangeBooklongDescription(e){
    this.setState({ longDescription: e.target.value })
  }
  onChangeBookstatus(e){
    this.setState({ status: e.target.value })
  }
  onChangeBookauthors(e){
    this.setState({ authors: e.target.value })
  }
  onChangeBookcategories(e){
    this.setState({ categories: e.target.value })
  }


  onSubmit(e) {
    e.preventDefault()

    const bookObject = {
      title: this.state.title,
      isbn: this.state.isbn,
      pageCount: this.state.pageCount,
      publishedDate: this.state.publishedDate,
      thumbnailUrl: this.state.thumbnailUrl,
      shortDescription: this.state.shortDescription,
      longDescription: this.state.longDescription,
      status: this.state.status,
      authors: this.state.authors,
      categories: this.state.categories

    };
    axios.post('http://localhost:4001/books/create-book', bookObject)
      .then(res => console.log(res.data));

    this.setState({ title: '', isbn: '', pageCount: '',
    publishedDate: '', thumbnailUrl: '',shortDescription: '',
    longDescription: '', status: '', authors: '', categories:''
  });

    // Redirect to Student List 
    this.props.history.push('/book-list')
  }

  render() {
    return (<div className="form-wrapper">
      <Form onSubmit={this.onSubmit}>
        <Form.Group controlId="title">
          <Form.Label>Title</Form.Label>
          <Form.Control type="text" value={this.state.title} onChange={this.onChangeBooktitle} />
        </Form.Group>

        <Form.Group controlId="isbn">
          <Form.Label>Isbn</Form.Label>
          <Form.Control type="number" value={this.state.isbn} onChange={this.onChangeBookisbn} />
        </Form.Group>

        <Form.Group controlId="pageCount">
          <Form.Label>Page Count</Form.Label>
          <Form.Control type="number" value={this.state.pageCount} onChange={this.onChangeBookpageCount} />
        </Form.Group>

        <Form.Group controlId="publishedDate">
          <Form.Label>publishedDate</Form.Label>
          <Form.Control type="datetime-local" value={this.state.publishedDate} onChange={this.onChangeBookpublishedDate} />
        </Form.Group>

        <Form.Group controlId="thumbnailUrl">
          <Form.Label>thumbnailUrl</Form.Label>
          <Form.Control type="text" value={this.state.thumbnailUrl} onChange={this.onChangeBookthumbnailUrl} />
        </Form.Group>

        <Form.Group controlId="shortDescription">
          <Form.Label>Short Description</Form.Label>
          <Form.Control type="text" value={this.state.shortDescription} onChange={this.onChangeBookshortDescription} />
        </Form.Group>

        <Form.Group controlId="longDescription">
          <Form.Label>Long Description</Form.Label>
          <Form.Control type="text" value={this.state.longDescription} onChange={this.onChangeBooklongDescription} />
        </Form.Group>

        <Form.Group controlId="status">
          <Form.Label>status</Form.Label>
          <Form.Control type="text" value={this.state.status} onChange={this.onChangeBookstatus} />
        </Form.Group>

        <Form.Group controlId="authors">
          <Form.Label>Authors</Form.Label>
          <Form.Control type="[]" value={this.state.authors} onChange={this.onChangeBookauthors} />
        </Form.Group>

        <Form.Group controlId="categories">
          <Form.Label>categories</Form.Label>
          <Form.Control type="[]" value={this.state.categories} onChange={this.onChangeBookcategories} />
        </Form.Group>

        <Button variant="danger" size="lg" block="block" type="submit" className="mt-4">
          Create Book
        </Button>
      </Form>
    </div>);
  }
}