const { json } = require('body-parser');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let bookSchema = new Schema({
  title: {
    type: String
  },
  isbn: {
    type: Number
  },
  pageCount: {
    type: Number
  },
  publishedDate: {
    type: Date
  }, 
  thumbnailUrl: {type: String},
  shortDescription: {type: String},
  longDescription: {type: String},
  status: {type: String},
  authors: {type: Array},
  categories: {type: Array}

}, {
    collection: 'book'
  })

module.exports = mongoose.model('Book', bookSchema)